package Model;

/**
 * La classe Ball rappresenta la palla in  gioco.
 * Contiene metodi per  muovere la palla, controllare le collisioni e recuperare informazioni sui dati di gioco.
 */
public class Ball {
    private int x, y; 
    private int speedX, speedY;
    private int score1, score2;
    
    /**
     * Costruisce un oggetto con posizione, velocità , punteggi iniziali predefiniti.
     */
    public Ball() {
        x = 250;
        y = 250;
        speedX = 9;
        speedY = 9;
        score1 = 0;
        score2 = 0;
    }

    /**
     * Sposta la palla aggiornando la sua posizione .
     */
    public void move() {
        x += speedX;
        y += speedY;
    }

    /**
     * Controlla la collisione della palla con le racchette.
     * Se la palla collide con una racchetta, cambia la sua velocità.
     * @param paddle1 La prima racchetta.
     * @param paddle2 La seconda racchetta.
     */
    public void checkCollisionWithPaddle(Paddle paddle1, Paddle paddle2) {
        if (x <= 20 && y >= paddle1.getY() && y <= paddle1.getY() + 80) {
            speedX = -speedX; 
        } else if (x >= 460 && y >= paddle2.getY() && y <= paddle2.getY() + 80) {
            speedX = -speedX;
        }
    }

    /**
     * Controlla la collisione della palla con i muri.
     * Se la palla collide con un muro, cambia direzione e aggiorna i punteggi.
     */
    public void checkCollisionWithWall() {
        if (x < 0 || x > 480) { 
            speedX = -speedX;
            if(x<-20 ||  x > 520) {
            	x = 250;
                y = 250;
                speedX = 9;
                speedY = 9;	
                score2=0;
                score1=0;
            }
            if (x < 0) {
                score2++;
            } else {
                score1++;
            }
        }
        if (y < 0 || y > 480) {
            speedY = -speedY;
        }
    }

    /**
     * Restituisce la coordinata x della palla.
     * @return La coordinata x della palla.
     */
    public int getX() {
        return x;
    }

    /**
     * Restituisce la coordinata y della palla.
     * 
     * @return La coordinata y della palla.
     */
    public int getY() {
        return y;
    }

    /**
     * Restituisce il punteggio del giocatore 2.
     * @return Il punteggio del giocatore 2.
     */
    public int getScore2() {
        return score2;
    }

    /**
     * Restituisce il punteggio del giocatore 1.
     * @return Il punteggio del giocatore 1.
     */
    public int getScore1() {
        return score1;
    }
}
