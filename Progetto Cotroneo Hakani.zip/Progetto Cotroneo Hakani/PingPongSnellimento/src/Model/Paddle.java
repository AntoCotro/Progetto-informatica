package Model;

/**
 * La classe Paddle rappresenta una racchetta.
 * Serve a colpire la palla e muoversi lungo l'asse y.
 */
public class Paddle {
	private int y;
	private final int x;
	private boolean movingUp;
	private boolean movingDown;

    /**
     * Costruisce una nuova racchetta con  posizioni  specificata. 
     * @param x La  x della racchetta.
     */
	public Paddle(int x) {
		this.x = x;
		y = 200;
	}
	
    /**
     * Sposta la racchetta verso l'alto.
     */
	public void moveUp() {
		if (y > 0) {
			y -= 5;
		}
	}
	 /**
     * Sposta la racchetta verso il basso.
     */
	public void moveDown() {
		if (y < 420) {
			y += 5;
		}
	}
	/**
     * Restituisce la posizione x della racchetta.
     * @return La  x della racchetta.
     */
	public int getX() {
		return x;
	}
    /**
     * Restituisce la posizione y della racchetta.
     * @return La y della racchetta.
     */
	public int getY() {
		return y;
	}
	/**
     * Verifica se la racchetta sta salendo.
     * @return True se la racchetta sta salendo, altrimenti false.
     */
	public boolean isMovingUp() {
		return movingUp;
	}
	/**
     * Verifica se la racchetta sta scendendo.
     * @return True se la racchetta sta scendendo, altrimenti false.
     */
	public boolean isMovingDown() {
		return movingDown;
	}
	 /**
     * Imposta lo stato della racchetta come "in salita" o "non in salita".
     * @param movingUp True se la racchetta sta salendo, altrimenti false.
     */
	public void setMovingUp(boolean movingUp) {
		this.movingUp = movingUp;
	}
	 /**
     * Imposta lo stato della racchetta come "in discesa" o "non in discesa".
     * @param movingDown True se la racchetta sta scendendo, altrimenti false.
     */
	public void setMovingDown(boolean movingDown) {
		this.movingDown = movingDown;
	}
}
