package Controller;

import Model.Ball;
import Model.Paddle;
import View.GameView;


/**
 * La classe GameController gestisce la logica del gioco.
 * Aggiorna la posizione della palla, delle racchette.
 */
public class GameController {
    private final Ball ball;
    private final Paddle paddle1;
    private final Paddle paddle2;
    private final GameView view;
    /**
     * Costruisce GameController con una palla, due racchette e una vista del gioco.
     * 
     * @param ball La palla del gioco.
     * @param paddle1 La prima racchetta del gioco.
     * @param paddle2 La seconda racchetta del gioco.
     * @param view La vista del gioco.
     */
    public GameController(Ball ball, Paddle paddle1, Paddle paddle2, GameView view) {
        this.ball = ball;
        this.paddle1 = paddle1;
        this.paddle2 = paddle2;
        this.view = view;
  
    }
    /**
     * Aggiorna lo stato del gioco.

     */
    public void updateGame() {
        ball.move();
        ball.checkCollisionWithPaddle(paddle1, paddle2);
        ball.checkCollisionWithWall();

        
        if (paddle1.isMovingUp()) {
            paddle1.moveUp();
        } else if (paddle1.isMovingDown()) {
            paddle1.moveDown();
        }
        
        if (paddle2.isMovingUp()) {
            paddle2.moveUp();
        } else if (paddle2.isMovingDown()) {
            paddle2.moveDown();
        }

        view.repaint();
    }
}
